/*
脚本功能：69萝莉 会员
下载地址：https://69luolic.com/?us=283W7F
在线观看地址: https://h5.l6rwut.com/
软件版本：所有
脚本作者：伟人
作者QQ:55749353
更新时间：2022-11-25
问题反馈：QQ+55749353
作者忠告:注意身体
QQ会员群：添加作者
TG反馈群：https://t.me/WeiRenQAQ
TG频道群：暂无
使用声明：⚠️此脚本仅供学习与交流，请勿转载与贩卖！⚠️⚠️⚠️

[rewrite_local]

#69萝莉酱

^http[s]?:\/\/h5.+((rwut)|(luoli)|(cmw)).+(com|cn)\/h5\/(movie/detail|search/movie).*$ url script-request-header https://raw.githubusercontent.com/WeiRen0/Scripts/main/69luolij.js

[mitm]
hostname = *rwut*,*luoli*,*cmw*
*/
/*
 * 加密工具已经升级了一个版本，目前为 jsjiami.com.v5 ，主要加强了算法，以及防破解【绝对不可逆】配置，耶稣也无法100%还原，我说的。;
 * 已经打算把这个工具基础功能一直免费下去。还希望支持我。
 * 另外 jsjiami.com.v5 已经强制加入校验，注释可以去掉，但是 jsjiami.com.v5 不能去掉（如果你开通了VIP，可以手动去掉），其他都没有任何绑定。
 * 誓死不会加入任何后门，jsjiami.com JS 加密的使命就是为了保护你们的Javascript 。
 * 警告：如果您恶意去掉 jsjiami.com.v5 那么我们将不会保护您的JavaScript代码。请遵守规则
 * 新版本: https://www.jsjiami.com/ 支持批量加密，支持大文件加密，拥有更多加密。 */
 
;var encode_version = 'jsjiami.com.v5', qfmqe = '__0xf05eb',  __0xf05eb=['5YmY6ZiX54qc5p+65YyT77yyBcO35Lyi5a+05p2E5b2556uL','wqRgw5cLw6rCqV0=','w51Lw5XCrcO3wrtqw4M=','w57CgG01w7huwowRw4VIw4XCvVLCsMO4woFbTH5Ee051wqNuG8KJMsO2wpMaw7Y=','wqwFRDXCmkzDqHMtZQ==','wp3DsRhlw4/DgMK3LcO1Y8OjT2xkVwLDisOlWj7DtXzDjSJaw5RqaMKOwrXCqMOkw5ovw5nCiGHCthXDgnfCvDLCnkYCw7jDjyHCjigPHmLDg8K8w5oObcOnwpXCrWPClkjCjHFAJMKxwoouw5YqwrTCiMK4A0fCisOgw4hbV0dUwqnCvMKVwrfCpArDvMOzw4ZgKcOlwq8MVcKnCMOsP3/DvcOSwpBZYsOVwqgPw7HCpcKNw7HCmVpow49jwr7CtmrCkMKWw7TDgjsfwqFvw6dEwppUNRAdBcKrBDxzQ0MQSMOTwq91TXoCw6rDoMOnwovDgsOTwpXCu2jCpcOgwq8wwp/DucK1TMKjw4Ncw4Y/c3gTw6HCo1INw5xpcAPDmMKCwodAwrbCvAfDo1XCrkTCih1mAcKbAcOHCyFuw7ovw7QlwrDCgg==','5L+s5Lii5bmd5L2u6aG/776g','HQHCoA==','wqVMSiZEwooZwqlr','IGfCrcOsfsOHwrvDlGQzchfDgMKd','54qY5pyO5Y+Z772PSMKQ5L2t5a2W5pyQ5byD56mx776X6L+x6K2+5pWa5o+F5oma5LmP55qP5bee5LyX'];(function(_0x4a40d6,_0x26bbb3){var _0x2aaa1f=function(_0x5c4851){while(--_0x5c4851){_0x4a40d6['push'](_0x4a40d6['shift']());}};_0x2aaa1f(++_0x26bbb3);}(__0xf05eb,0x1cf));var _0x5ec4=function(_0x3c2792,_0x2e257b){_0x3c2792=_0x3c2792-0x0;var _0x5e7d39=__0xf05eb[_0x3c2792];if(_0x5ec4['initialized']===undefined){(function(){var _0x1a734a=typeof window!=='undefined'?window:typeof process==='object'&&typeof require==='function'&&typeof global==='object'?global:this;var _0x4e325a='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';_0x1a734a['atob']||(_0x1a734a['atob']=function(_0x25a92a){var _0x315fdb=String(_0x25a92a)['replace'](/=+$/,'');for(var _0x588715=0x0,_0x53cce9,_0x1d3312,_0x239fe8=0x0,_0x1c4f36='';_0x1d3312=_0x315fdb['charAt'](_0x239fe8++);~_0x1d3312&&(_0x53cce9=_0x588715%0x4?_0x53cce9*0x40+_0x1d3312:_0x1d3312,_0x588715++%0x4)?_0x1c4f36+=String['fromCharCode'](0xff&_0x53cce9>>(-0x2*_0x588715&0x6)):0x0){_0x1d3312=_0x4e325a['indexOf'](_0x1d3312);}return _0x1c4f36;});}());var _0x37abca=function(_0x10c1d7,_0x48a812){var _0x514dc3=[],_0x2e6369=0x0,_0x5134ea,_0x50e3eb='',_0x5edcd3='';_0x10c1d7=atob(_0x10c1d7);for(var _0x2c4f23=0x0,_0x213396=_0x10c1d7['length'];_0x2c4f23<_0x213396;_0x2c4f23++){_0x5edcd3+='%'+('00'+_0x10c1d7['charCodeAt'](_0x2c4f23)['toString'](0x10))['slice'](-0x2);}_0x10c1d7=decodeURIComponent(_0x5edcd3);for(var _0x5c3c61=0x0;_0x5c3c61<0x100;_0x5c3c61++){_0x514dc3[_0x5c3c61]=_0x5c3c61;}for(_0x5c3c61=0x0;_0x5c3c61<0x100;_0x5c3c61++){_0x2e6369=(_0x2e6369+_0x514dc3[_0x5c3c61]+_0x48a812['charCodeAt'](_0x5c3c61%_0x48a812['length']))%0x100;_0x5134ea=_0x514dc3[_0x5c3c61];_0x514dc3[_0x5c3c61]=_0x514dc3[_0x2e6369];_0x514dc3[_0x2e6369]=_0x5134ea;}_0x5c3c61=0x0;_0x2e6369=0x0;for(var _0x24385c=0x0;_0x24385c<_0x10c1d7['length'];_0x24385c++){_0x5c3c61=(_0x5c3c61+0x1)%0x100;_0x2e6369=(_0x2e6369+_0x514dc3[_0x5c3c61])%0x100;_0x5134ea=_0x514dc3[_0x5c3c61];_0x514dc3[_0x5c3c61]=_0x514dc3[_0x2e6369];_0x514dc3[_0x2e6369]=_0x5134ea;_0x50e3eb+=String['fromCharCode'](_0x10c1d7['charCodeAt'](_0x24385c)^_0x514dc3[(_0x514dc3[_0x5c3c61]+_0x514dc3[_0x2e6369])%0x100]);}return _0x50e3eb;};_0x5ec4['rc4']=_0x37abca;_0x5ec4['data']={};_0x5ec4['initialized']=!![];}var _0xc3f404=_0x5ec4['data'][_0x3c2792];if(_0xc3f404===undefined){if(_0x5ec4['once']===undefined){_0x5ec4['once']=!![];}_0x5e7d39=_0x5ec4['rc4'](_0x5e7d39,_0x2e257b);_0x5ec4['data'][_0x3c2792]=_0x5e7d39;}else{_0x5e7d39=_0xc3f404;}return _0x5e7d39;};var modifiedHeaders=$request[_0x5ec4('0x0','!A%z')];modifiedHeaders['uid']=_0x5ec4('0x1',')#Aw');modifiedHeaders['token']=_0x5ec4('0x2','vxYG');modifiedHeaders[_0x5ec4('0x3','t1Cg')]='Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2015_3_1\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/15.3\x20Mobile/15E148\x20Safari/604.1';modifiedHeaders['Cookie']=_0x5ec4('0x4','aCCO');$notify(_0x5ec4('0x5','aCCO'));$done({'headers':modifiedHeaders});;(function(_0x35b94f,_0x44e0f5,_0x2fb660){var _0x22ca58={'HRWii':function _0x1a6505(_0x50d112,_0x409e40){return _0x50d112!==_0x409e40;}};_0x2fb660='al';try{_0x2fb660+=_0x5ec4('0x6','n8&5');_0x44e0f5=encode_version;if(!(_0x22ca58['HRWii'](typeof _0x44e0f5,_0x5ec4('0x7','uUTn'))&&_0x44e0f5===_0x5ec4('0x8','YBJd'))){_0x35b94f[_0x2fb660]('删除'+_0x5ec4('0x9','uUTn'));}}catch(_0x3137eb){_0x35b94f[_0x2fb660](_0x5ec4('0xa','n8&5'));}}(window));;encode_version = 'jsjiami.com.v5';
