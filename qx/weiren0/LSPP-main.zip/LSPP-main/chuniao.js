
var hausd0rff = $request.headers;

    hausd0rff['X-TOKEN'] = 'xOIby5DWr2tCf/OxKvnSZoHnD36X8YyzazHwXpj8r+Vqkqa30wWe5PIarCBfLcUuYQfrSQKrtwdb7Un7dQesn3opn4Dw39HpJtFipm7B7Np0SCBYKelhyBMOy9ZKbIhpWA22y6C9NxEQOk9JVEgPj+NsSTs6jq8akUhr8HshbjH8HZBmS5ur0lIWNl5KADZ0SYrLRBUqjNsl9tLSHyE+QGQbDIqidP4ahsi1CLiCmy2QgrM5pLGgrWJgjudsFIPgYvuZfISacVQhwKXKbY00co+6zKflsztXh7X1rpasaH0PcFqe7DaXscND4YY7FSIwMnNBCu1ryCAtne+uiTHwoVKZpCWDfgnoTM0Kr5O7Re8J184qQWmVsHl4ZrIpOgMnt4Qxzrp/WfTyZeto0u9e17RpJRt4BgTgLxLafQ6Ku/IwHh+5UXhPRv/JNKFO2qIhp+onypxrEXBMXhfLk7WfREXSzBiR9lKW6c6Y14uHOsKukSY99ncIbFPRIR0Y8SBSqwHaz7yUqyILAvWlQT9juF5hxq/VxPmgoRb3/f+HQNFfoJihCXL+vHkc/GUDt+ygvo6PWc3PgpFxigYcEBqCVlaHnMecEFXiBQXJulTq9dWFgooaz4iPCdExiV5saLfrJ4rqZBr57RDWN1GnGRnJFAQ9OET/qsDC+auDRB/+JZU=';

    hausd0rff['User-Agent'] = 'GKDYVideo/1.0 (iPhone; iOS 12.4.4; Scale/2.00)';
    

$done({headers : hausd0rff});
